# Anypoint MQ Export

Exports Anypoint MQ **queue and exchange settings (no messages)** from **all Business Groups** and **all environments** to an Excel file.

## Read-only
The script only issues HTTP GET requests to Anypoint. It does not create, modify, delete or purge anything, does not read or consume messages, and the only thing it writes is the local output file. A token with read-only access to Business Groups, environments and Anypoint MQ is enough.

## Requirements
- PowerShell 5.1+ or 7
- `Install-Module ImportExcel -Scope CurrentUser` (Excel not needed; without it, CSV is written)
- Anypoint access token with read access to Business Groups, environments and Anypoint MQ

## Usage
```powershell
.\Export-AnypointMQ.ps1                       # prompts for token (visible)
.\Export-AnypointMQ.ps1 -Token $t -OutputPath C:\temp\mq.xlsx
.\Export-AnypointMQ.ps1 -BaseUrl https://eu1.anypoint.mulesoft.com
```

## Output
`Queues` sheet columns: Business Group, Environment, Queue Name, Type (Standard/FIFO), Encryption Enabled (Yes/No), Encryption Details, Default TTL (ms), Default Lock TTL (ms), Default Delivery Delay, Max Deliveries, Dead Letter Queue.
`Exchanges` sheet columns: Business Group, Environment, Exchange Name, Encryption Enabled, Encryption Details, Bound Queues (queues bound to the exchange).
`Encryption Details` lists any additional encryption-related attributes the API returns for the queue (blank if none).
`Errors` sheet (only if something failed, e.g. 403 on an environment); the run continues.
