<#
.SYNOPSIS
  Exports Anypoint MQ queue and exchange settings (no messages) from ALL Business Groups and
  ALL environments to an Excel file.

.NOTES
  READ-ONLY: every call to Anypoint is an HTTP GET. The script never creates, updates,
  deletes, purges or consumes anything, and never reads message contents. The only thing
  it writes is the local output file.

.PARAMETER Token
  Anypoint access token. If omitted you are prompted (input is visible).

.PARAMETER BaseUrl
  Control plane URL. US: https://anypoint.mulesoft.com (default)
  EU: https://eu1.anypoint.mulesoft.com   GovCloud: https://gov.anypoint.mulesoft.com

.PARAMETER OutputPath
  Output .xlsx path. Default: .\AnypointMQ_Export_<timestamp>.xlsx

.EXAMPLE
  .\Export-AnypointMQ.ps1
  .\Export-AnypointMQ.ps1 -Token $t -OutputPath C:\temp\mq.xlsx
#>
[CmdletBinding()]
param(
    [string]$Token,
    [string]$BaseUrl = 'https://anypoint.mulesoft.com',
    [string]$OutputPath = (Join-Path (Get-Location) ("AnypointMQ_Export_{0}.xlsx" -f (Get-Date -Format 'yyyyMMdd_HHmmss')))
)

$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$BaseUrl = $BaseUrl.TrimEnd('/')

if (-not $Token) { $Token = Read-Host 'Enter Anypoint token' }   # visible on purpose
$Token = $Token.Trim() -replace '^(?i)bearer\s+', ''
$Headers = @{ Authorization = "Bearer $Token" }

# ---------- helpers ----------
# Read-only by design: the HTTP method is hard-coded to GET and there is no parameter to change it.
function Invoke-Anypoint {
    param([string]$Path, [int]$Retries = 3)
    if ($Path -match '/(messages|purge)(/|\?|$)') { throw "Blocked: read-only script must not touch '$Path'" }
    $uri = "$BaseUrl$Path"
    for ($i = 1; $i -le $Retries; $i++) {
        try { return Invoke-RestMethod -Uri $uri -Headers $Headers -Method Get -ContentType 'application/json' }
        catch {
            $code = $_.Exception.Response.StatusCode.value__
            if ($code -in 429, 500, 502, 503, 504 -and $i -lt $Retries) { Start-Sleep -Seconds (2 * $i); continue }
            throw
        }
    }
}

function Get-AllBusinessGroups {
    param([string]$RootOrgId)
    $root = Invoke-Anypoint "/accounts/api/organizations/$RootOrgId/hierarchy"
    $list = [System.Collections.Generic.List[object]]::new()
    function Walk($node, $parentPath) {
        $path = if ($parentPath) { "$parentPath/$($node.name)" } else { $node.name }
        $list.Add([pscustomobject]@{ Id = $node.id; Name = $node.name; Path = $path })
        foreach ($c in @($node.subOrganizations)) { if ($c) { Walk $c $path } }
    }
    Walk $root $null
    $list
}

function Get-MqDestinations {
    param($OrgId, $EnvId, $RegionId)
    $all = @(); $offset = 0; $limit = 100
    do {
        $page = Invoke-Anypoint "/mq/admin/api/v1/organizations/$OrgId/environments/$EnvId/regions/$RegionId/destinations?limit=$limit&offset=$offset"
        $items = @($page)
        $all += $items
        $offset += $limit
    } while ($items.Count -eq $limit)
    $all
}

function Get-Prop($obj, $name) { if ($null -ne $obj -and $obj.PSObject.Properties[$name]) { $obj.$name } else { $null } }

# ---------- authenticate / discover ----------
Write-Host 'Validating token...' -ForegroundColor Cyan
$me = Invoke-Anypoint '/accounts/api/me'
$rootOrgId = $me.user.organization.id
Write-Host ("Authenticated as {0} (root org: {1})" -f $me.user.username, $me.user.organization.name) -ForegroundColor Green

$businessGroups = Get-AllBusinessGroups -RootOrgId $rootOrgId
Write-Host ("Found {0} business group(s)." -f $businessGroups.Count)

$queues = [System.Collections.Generic.List[object]]::new()
$exchanges = [System.Collections.Generic.List[object]]::new()
$errors = [System.Collections.Generic.List[object]]::new()

foreach ($bg in $businessGroups) {
    Write-Host "`nBusiness Group: $($bg.Path)" -ForegroundColor Yellow
    try { $envs = (Invoke-Anypoint "/accounts/api/organizations/$($bg.Id)/environments").data }
    catch { $errors.Add([pscustomobject]@{ 'Business Group' = $bg.Path; Environment = ''; Step = 'List environments'; Error = $_.Exception.Message }); continue }

    foreach ($env in $envs) {
        Write-Host "  Environment: $($env.name)"
        try { $regions = @(Invoke-Anypoint "/mq/admin/api/v1/organizations/$($bg.Id)/environments/$($env.id)/regions") }
        catch { $errors.Add([pscustomobject]@{ 'Business Group' = $bg.Path; Environment = $env.name; Step = 'List regions'; Error = $_.Exception.Message }); continue }

        foreach ($r in $regions) {
            $regionId = if ($r.regionId) { $r.regionId } else { $r.id }
            try { $dests = Get-MqDestinations -OrgId $bg.Id -EnvId $env.id -RegionId $regionId }
            catch { $errors.Add([pscustomobject]@{ 'Business Group' = $bg.Path; Environment = $env.name; Step = "List destinations ($regionId)"; Error = $_.Exception.Message }); continue }

            foreach ($d in $dests) {
                # message exchanges
                if (($d.type -eq 'exchange') -or ($d.exchangeId -and -not $d.queueId)) {
                    $x = $d
                    try { $x = Invoke-Anypoint "/mq/admin/api/v1/organizations/$($bg.Id)/environments/$($env.id)/regions/$regionId/destinations/exchanges/$($d.exchangeId)" } catch {}
                    $bound = ''
                    try {
                        $b = @(Invoke-Anypoint "/mq/admin/api/v1/organizations/$($bg.Id)/environments/$($env.id)/regions/$regionId/bindings/exchanges/$($d.exchangeId)")
                        $bound = ($b | ForEach-Object { if ($_.queueId) { $_.queueId } elseif ($_.id) { $_.id } } | Where-Object { $_ }) -join '; '
                    } catch {}
                    $xEncExtra = @($x.PSObject.Properties |
                        Where-Object { $_.Name -match 'encrypt|kms|cipher|key' -and $_.Name -ne 'encrypted' } |
                        ForEach-Object { "$($_.Name)=$($_.Value)" }) -join '; '
                    $exchanges.Add([pscustomobject][ordered]@{
                        'Business Group'     = $bg.Path
                        'Environment'        = $env.name
                        'Exchange Name'      = $d.exchangeId
                        'Encryption Enabled' = if (Get-Prop $x 'encrypted') { 'Yes' } else { 'No' }
                        'Encryption Details' = $xEncExtra
                        'Bound Queues'       = $bound
                    })
                    continue
                }

                $q = $d
                try { $q = Invoke-Anypoint "/mq/admin/api/v1/organizations/$($bg.Id)/environments/$($env.id)/regions/$regionId/destinations/queues/$($d.queueId)" } catch {}

                # Any extra encryption-related attributes the API returns (beyond the Encrypted flag)
                $encExtra = @($q.PSObject.Properties |
                    Where-Object { $_.Name -match 'encrypt|kms|cipher|key' -and $_.Name -ne 'encrypted' } |
                    ForEach-Object { "$($_.Name)=$($_.Value)" }) -join '; '

                $queues.Add([pscustomobject][ordered]@{
                    'Business Group'         = $bg.Path
                    'Environment'            = $env.name
                    'Queue Name'             = $q.queueId
                    'Type'                   = if (Get-Prop $q 'fifo') { 'FIFO' } else { 'Standard' }
                    'Encryption Enabled'     = if (Get-Prop $q 'encrypted') { 'Yes' } else { 'No' }
                    'Encryption Details'     = $encExtra
                    'Default TTL (ms)'       = Get-Prop $q 'defaultTtl'
                    'Default Lock TTL (ms)'  = Get-Prop $q 'defaultLockTtl'
                    'Default Delivery Delay' = Get-Prop $q 'defaultDeliveryDelay'
                    'Max Deliveries'         = Get-Prop $q 'maxDeliveries'
                    'Dead Letter Queue'      = Get-Prop $q 'deadLetterQueueId'
                })
            }
        }
    }
}

# ---------- output ----------
if (-not (Get-Module -ListAvailable -Name ImportExcel)) {
    Write-Warning 'ImportExcel module not found (Install-Module ImportExcel -Scope CurrentUser). Writing CSV files instead.'
    $base = [IO.Path]::ChangeExtension($OutputPath, $null).TrimEnd('.')
    $queues | Export-Csv "${base}_Queues.csv" -NoTypeInformation
    if ($exchanges.Count) { $exchanges | Export-Csv "${base}_Exchanges.csv" -NoTypeInformation }
    if ($errors.Count) { $errors | Export-Csv "${base}_Errors.csv" -NoTypeInformation }
    Write-Host "CSV files written next to $OutputPath" -ForegroundColor Green
    return
}

Import-Module ImportExcel
if (Test-Path $OutputPath) { Remove-Item $OutputPath -Force }
$common = @{ Path = $OutputPath; AutoSize = $true; FreezeTopRow = $true; AutoFilter = $true; BoldTopRow = $true }
if ($queues) { $queues | Export-Excel @common -WorksheetName 'Queues' }
if ($exchanges.Count) { $exchanges | Export-Excel @common -WorksheetName 'Exchanges' }
if ($errors.Count) { $errors | Export-Excel @common -WorksheetName 'Errors' }

Write-Host ("`nDone. {0} queue(s), {1} exchange(s), {2} error(s)." -f $queues.Count, $exchanges.Count, $errors.Count) -ForegroundColor Green
Write-Host "Output: $OutputPath"
